import tkinter as tk
from tkinter import simpledialog
import keyring
import os
from os.path import expanduser
import pynmcli
import subprocess
import pexpect
import time
from shutil import which
from netifaces import interfaces

# Checks if the command is installed
def ls_command(name):
    return which(name) is not None

# TODO : Cleanup du code et couper la fonction en deux !
# Checks if the user has set up a connection to a given network
def checkNet(network):

    ifaces = "ip link show | grep w | cut -d \" \" -f 2 | rev |cut -c 2- | rev"
    wifi = subprocess.getoutput(ifaces)
    if not wifi:
        return False

    net = "nmcli connection show " + network
    process = subprocess.Popen(net.split(), stdout=subprocess.PIPE)
    isconf = False
    while True:
        output = process.stdout.readline()
        if (b'connection.id:') in output :
            isconf = True
        if output.startswith(b'') and process.poll() is not None:
            break
    rc = process.poll()

    if isconf :
        print("Connection is already set")
    else :
        # TODO : Automatic get of interface
        net = "nmcli con add type wifi ifname " + wifi + " con-name "+ network + " ssid " + network
        process = subprocess.Popen(net.split(), stdout=subprocess.PIPE)

    time.sleep(3)
    return True


# Connects the user to a network
def connect(username, password, ext, network):
    command = "nmcli con edit id " + network
    method = "set ipv4.method auto"
    eap = "set 802-1x.eap peap"
    auth = "set 802-1x.phase2-auth mschapv2"
    mgmt = "set wifi-sec.key-mgmt wpa-eap"
    user = "set 802-1x.identity " + username + ext

    pwd = "set 802-1x.password " + password
    save = "save"
    acti = "activate"
    quit = "quit"

    child = pexpect.spawn(command)
    child.expect('nmcli>')
    child.sendline(method)

    child.expect('nmcli>')
    child.sendline(eap)

    child.expect('nmcli>')
    child.sendline(auth)

    child.expect('nmcli>')
    child.sendline(mgmt)

    child.expect('nmcli>')
    child.sendline(user)

    child.expect('nmcli>')
    child.sendline(pwd)

    child.expect('nmcli>')
    child.sendline(save)

    child.expect('nmcli>')
    child.sendline(acti)

    child.expect('Connection successfully activated')
    child.sendline()

    child.expect('nmcli>')
    child.sendline(save)

    child.expect('nmcli>')
    child.sendline(quit)

#MAGIC_USERNAME_KEY = 'yo'

#service_id = 'test'

# This part is used to get a GUI prompt to enter your creds

application_window = tk.Tk()
username = simpledialog.askstring("Input", "What is your username for AAI (surname.name)", parent=application_window)
password = simpledialog.askstring("Input", "What is your password", parent=application_window, show='*')


# This part is used to store the password inside the python script not outside

#keyring.set_password(service_id, username, password)
#print(keyring.get_password(service_id, username))

# This part sets up the HEIG-VD network

if checkNet("HEIG-VD"):
    connect(username, password, "@heig-vd.ch", "HEIG-VD")
else:
    print("no interface to work with")

# This part sets up the eduroam network

# TODO : integration du script eduroam-linux-HES-SO.py

if checkNet("eduroam"):
    connect(username, password, "@hes-so.ch", "eduroam")
else:
    print("no interface to work with")

# This part sets up the VPN

#file_path = expanduser("~/.zshrc")
#file_object = open(file_path, 'a')
#alias = "alias vpnHEIG=\"sudo openconnect --authgroup=All_Users --user=" + username + " https://remote.heig-vd.ch\" \n"
#file_object.write(alias)

# This part sets up the printers
#deps = False

# TODO : Add exec commands
#if ls_command("cups"):
#    command = "sudo apt-get -y install cups"
#    deps = True
#if ls_command("samba"):
#    command = "sudo apt-get -y install samba"
#    deps = True
#if ls_command("python3-smbc"):
#    command = "sudo apt-get -y install python3-smbc"
#    deps = True

#if deps:
#    command = "sudo apt-get -y install -f"

# PPD file has to be placed in "~/driver/"
#ppd_path = expanduser("~/driver/HEIG_Printer.ppd")
#printer = "lpadmin -p FOLLOWME_PS -E -v smb://EINET/" + username + ":" + password + "@print.einet.ad.eivd.ch/FOLLOWME_PS -P " + ppd_path + " -L \"HEIG-VD\" -o auth-info-required=negotiate"
#process = subprocess.Popen(printer.split(), stdout=subprocess.PIPE)


# This part sets up the eistore shares

#create_eistore0 = "sudo mkdir /mnt/eistore0"
#eistore0 = "sudo mount -v -t cifs -o domain=EINET,username=" + username + " //eistore0/softs /mnt/eistore0"
#alias0 = "alias eistore0=\"" + eistore0 + "\"\n"
#create_eistore1 = "sudo mkdir /mnt/eistore1"
#eistore1 = "sudo mount -v -t cifs -o domain=EINET,username=" + username + " //eistore1/softs / mnt/eistore0"
#alias1 = "alias eistore1=\"" + eistore1 + "\"\n"

#file_object.write(alias0)
#file_object.write(alias1)

#file_object.close()

